// src/services/api.js

import axios from "axios";

// Determine API base URL
const getApiBaseUrl = () => {
  // Check environment variable first
  if (import.meta.env.VITE_API_BASE) {
    return import.meta.env.VITE_API_BASE;
  }
  
  // Default to localhost for development
  const { protocol, hostname, port } = window.location;
  if (port === "5173" || port === "3000") {
    // Development mode - backend on port 8000
    return `${protocol}//${hostname}:8000`;
  }
  
  // Production - use same origin
  return `${protocol}//${hostname}${port ? ":" + port : ""}`;
};

const api = axios.create({
  baseURL: getApiBaseUrl() + "/api",
  headers: {
    "Content-Type": "application/json",
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("access_token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Unauthorized - clear token and redirect to login
      localStorage.removeItem("access_token");
      window.location.href = "/";
    }
    return Promise.reject(error);
  }
);

export default api;