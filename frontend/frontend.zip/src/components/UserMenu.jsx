// src/components/UserMenu.jsx

import React, { useState, useRef, useEffect } from "react";
import { ChevronDown, User, LogOut, Settings, Shield } from "lucide-react";
import { useNavigate } from "react-router-dom";

const UserMenu = ({ firstName, lastName, role, onLogout, enhanced = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const getRoleColor = () => {
    switch (role) {
      case "admin":
        return "bg-purple-100 text-purple-700";
      case "owner":
        return "bg-red-100 text-red-700";
      default:
        return "bg-blue-100 text-blue-700";
    }
  };

  const getRoleIcon = () => {
    switch (role) {
      case "admin":
      case "owner":
        return <Shield className="h-4 w-4" />;
      default:
        return <User className="h-4 w-4" />;
    }
  };

  const handleLogout = () => {
    onLogout();
    navigate("/");
  };

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition ${
          enhanced ? "border border-gray-200" : ""
        }`}
      >
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-sm font-medium">
            {firstName?.[0]}{lastName?.[0]}
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-sm font-medium text-gray-900">
              {firstName} {lastName}
            </p>
            <p className={`text-xs px-1.5 py-0.5 rounded-full inline-flex items-center gap-1 ${getRoleColor()}`}>
              {getRoleIcon()}
              {role}
            </p>
          </div>
        </div>
        <ChevronDown className={`h-4 w-4 text-gray-500 transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50">
          <div className="px-4 py-2 border-b border-gray-100">
            <p className="text-sm font-medium text-gray-900">
              {firstName} {lastName}
            </p>
            <p className="text-xs text-gray-500">{role} account</p>
          </div>

          <a
            href="/UserProfileForm"
            className="flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
          >
            <User className="h-4 w-4" />
            <span>Profile Settings</span>
          </a>

          {(role === "admin" || role === "owner") && (
            <a
              href="/admin"
              className="flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
            >
              <Settings className="h-4 w-4" />
              <span>Admin Panel</span>
            </a>
          )}

          <hr className="my-1 border-gray-100" />

          <button
            onClick={handleLogout}
            className="w-full text-left flex items-center space-x-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50"
          >
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default UserMenu;